<?php
$GLOBALS['SITE_DB']->query_insert('theme_images', array('id' => 'main-bg', 'theme' => 'portfolio', 'path' => 'themes/portfolio/images_custom/./main-bg.png', 'lang' => 'EN'), false, true);
$GLOBALS['SITE_DB']->query_insert('theme_images', array('id' => '2logo-default', 'theme' => 'portfolio', 'path' => 'themes/portfolio/images_custom/2logo-default.png', 'lang' => 'EN'), false, true);
$GLOBALS['SITE_DB']->query_insert('theme_images', array('id' => 'logo', 'theme' => 'portfolio', 'path' => 'themes/portfolio/images_custom/./2logo-default.png', 'lang' => 'EN'), false, true);
$GLOBALS['SITE_DB']->query_insert('theme_images', array('id' => 'logo/-logo', 'theme' => 'portfolio', 'path' => 'themes/portfolio/images_custom/logo/logo-default.png', 'lang' => 'EN'), false, true);
$GLOBALS['SITE_DB']->query_insert('theme_images', array('id' => 'logo-default', 'theme' => 'portfolio', 'path' => 'themes/portfolio/images_custom/logo-default.png', 'lang' => 'EN'), false, true);
