<?php
global $SITE_INFO;
$SITE_INFO['default_lang'] = 'EN';
$SITE_INFO['db_type'] = 'mysql';
$SITE_INFO['forum_type'] = 'cns';
$SITE_INFO['domain'] = 'csm.wearebeatgrid.com';
$SITE_INFO['base_url'] = 'http://csm.wearebeatgrid.com';
$SITE_INFO['table_prefix'] = 'kawu_';
$SITE_INFO['master_password'] = '6e5228873f88f4ef48507f4f79922f7b';
$SITE_INFO['use_persistent'] = '0';
$SITE_INFO['db_site'] = 'csm';
$SITE_INFO['db_site_host'] = 'localhost';
$SITE_INFO['db_site_user'] = 'csm';
$SITE_INFO['db_site_password'] = 'tyWZ6jcMvtNterR7';
$SITE_INFO['user_cookie'] = 'kawu_member_id';
$SITE_INFO['pass_cookie'] = 'kawu_member_hash';
$SITE_INFO['cookie_domain'] = '';
$SITE_INFO['cookie_path'] = '/';
$SITE_INFO['cookie_days'] = '120';
$SITE_INFO['db_forums'] = 'csm';
$SITE_INFO['db_forums_host'] = 'localhost';
$SITE_INFO['db_forums_user'] = 'csm';
$SITE_INFO['db_forums_password'] = 'tyWZ6jcMvtNterR7';
$SITE_INFO['cns_table_prefix'] = 'kawu_';
$SITE_INFO['self_learning_cache'] = '1';
$SITE_INFO['multi_lang_content'] = '0';

